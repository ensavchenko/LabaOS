---
## Front matter
lang: ru-RU
title: Дискреционное разграничение прав в Linux. Основные атрибуты
author: |
	 Савченко Елизавета	НБИ-01-20\inst{1}

institute: |
	\inst{1}Российский Университет Дружбы Народов

date: 23 сентября, 2023, Москва, Россия

## Formatting
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true

---

# Цели и задачи работы

## Цель лабораторной работы

Получение практических навыков работы в консоли с атрибутами файлов для групп пользователей.

# Процесс выполнения лабораторной работы

## Определяем UID и группу двух пользователей

![guest](image/01.png){ #fig:001 width=70% height=70% }

## Файл с данными о пользователях

![сравнение](image/02.png){ #fig:002 width=70% height=70% }

## Второй файл с данными о пользователях

![сравнение второго](image/03.png){ #fig:003 width=70% height=70% }

## Сравните полученную информацию с содержимым файла

![сравнение полученного](image/04.png){ #fig:004 width=70% height=70% }

## Выполнение регистрации пользователя guest2 в группе guest

![выполнение регистрации](image/05.png){ #fig:005 width=70% height=70% }

## Атрибуты директории

![изменение прав директории](image/06.png){ #fig:006 width=70% height=70% }

## Заполнение таблицы

![заполнение таблицы](image/07.png){ #fig:007 width=70% height=70% }


## Права и разрешённые действия

![минимальные права для совершения операций](image/08.png){ #fig:008 width=70% height=70% }

# Выводы по проделанной работе

## Вывод

В ходе выполнения работы, мы смогли приобрести практические навыки работы в консоли с атрибутами файлов для групп пользователей.